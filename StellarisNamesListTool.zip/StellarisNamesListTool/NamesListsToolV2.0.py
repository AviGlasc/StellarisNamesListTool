# Avi's Stellaris Names List Tool V1.1; 2/3/2025
# This tool is designed to help Stellaris modders create names lists for their mods.
# This tool is built around the google sheets template available here: https://docs.google.com/spreadsheets/d/1GpY67q_PQ5TbjV4x9hqWE4KWJxhgVF0coUvGhxl-C4o/edit?usp=sharing

# To get started, copy the above file to your own Google Drive and set it to public access.
# The first page of the document is the tutorial page, which explains how to use the template, and any subsequent pages are the actual name lists themselves.
# Send the document to all of your collaborators and have them fill in the name lists as needed.
# Each new name list should be on a new page, and the name of the page will be the name of the list in the game, page name is also automatically updated from the 'NamesList Title' cell.
# Once all of the name lists are filled in, the tool user needs to go through each sheet and set the 'Enable List Processing:' ell to TRUE (checked), without this checked the page will be skipped.
# These will be put into a folder called "ASNLT_output" in the same directory as the tool. Make sure to take the TXT files out of this folder before placing them in the name_lists folder.

# Currently, the tool only supports the google sheets format. Future versions may support other formats.
# There is no automated support for sequential names at this time, but this will be added in the future, as well as added manually with a little bit of research (if you're interested, just look at the localization files in the game and compare them with the nameslist).
# The tool requires the pandas library to be installed. This can be done by running "pip install pandas" in the command line.

# If you notice issues or have suggestions for the tool, please let me know via my email: avilynnglasc@gmail.com
# If you're more savvy, feel free to fork the repository and make your own changes. I'd love to see what you come up with!
# For those wanting to learn about the Stellaris side of things, check out the Stellaris wiki page: https://stellaris.paradoxwikis.com/Empire_modding#Name_lists or the README file in the Stellaris/common/name_lists folder.

# Importing the required libraries
import pandas as pd
import re
import string
import openpyxl
import requests
from string import Template 
import os


NONALLOWEDCHARS = ['$', '%', '/', '{', '}', ',']
REPLACEMENTCHARS = ['S', 'P', ' ', '', '', ' ']
DIRECTORYNAME = "ASNLT_output" # The name of the directory where the output files will be saved

txtfiles = []
yamlfiles = []
total_duplicates = [] # Set to store all duplicate entries found in the document
sheet_duplicates = {} # Set to store all duplicate entries found in the sheet


#df.iloc uses [row, column] 0 indexed, very first row is reserved for df.columns entries, so "row 0" in code is actually row 2 in the sheet

def check_and_replace(array_of_strings, non_allowed_chars, replacement_chars, column_index):
    # Create a dictionary for quick lookup of replacements
    replacement_dict = dict(zip(non_allowed_chars, replacement_chars))
    
    # Process each string in the array
    cleaned_array = []
    seen_entries = {}
    for idx, s in enumerate(array_of_strings):
        s = str(s).strip()  # Ensure the entry is treated as a string, allowing numbers in names, and strip whitespace
        if pd.isna(s) or s == 'nan':
            continue  # Skip "nan" values
        for char in non_allowed_chars:
            if char in s:
                s = s.replace(char, replacement_dict[char])
        s = s.rstrip()  # Remove trailing spaces
        
        if s not in seen_entries: # Only store values that haven't been seen before
            seen_entries[s] = (idx + 5, num2col(column_index))  # Store the row and column indices for the first appearance (1-based, extra 4 for headers), column doesnt need this as it's already handled in the converting function
            cleaned_array.append(s)
        else:
            if s not in sheet_duplicates:
                sheet_duplicates[s] = [seen_entries[s]]
            sheet_duplicates[s].append((idx + 5, num2col(column_index))) # Store the row and column indices for the second appearance (1-based, extra 4 for headers)
            
    return cleaned_array

def sequential_check(cleaned_array, sheet_name):
    sequentialComponent = []
    nonsequentialComponent = []
    for s in cleaned_array:
        # Check for sequential names, these are names that are in the format \XXX, where XXX is a three-letter code
        sequential_match = re.search(r'\\[A-Z]{3}', s)
        if sequential_match:
            sequentialComponent.append(f'sequential_name = {sheet_name.upper()}_{s.upper()}') # Rewrite the stored entries to the sequential format used for Stellaris and hand them through
            cleaned_array.remove(s) # Remove the sequential entry from the cleaned array
    nonsequentialComponent = cleaned_array

    return sequentialComponent, nonsequentialComponent

def convert_google_sheet_url(url):
    # Regular expression to match and capture the necessary part of the URL
    pattern = r'https://docs\.google\.com/spreadsheets/d/([a-zA-Z0-9-_]+)(/edit#gid=(\d+)|/edit.*)?'

    # Replace function to construct the new URL for CSV export
    # If gid is present in the URL, it includes it in the export URL, otherwise, it's omitted
    replacement = lambda m: f'https://docs.google.com/spreadsheets/d/{m.group(1)}/export?' + (f'gid={m.group(3)}&' if m.group(3) else '') + 'format=xlsx'

    # Replace using regex
    new_url = re.sub(pattern, replacement, url)

    return new_url

def replace_key(three_digit_id):
    match three_digit_id:
        case "\crd":
            return "C"
        case "\ord":
            return "ORD"
        case "rom":
            return "R"
        case "hex":
            return "HEX"
        
def concatenate_column_data(df, columnGrab, sheet_name, startValue=3):
    # Grabs column data from column =columnGrab from a data frame =df starting at the row=startValue and continuing downward

    # Grab the column data from the dataframe and convert to array
    columnData = df.iloc[startValue:, columnGrab]
    columnList = columnData.to_numpy()
    
    # Check for and replace any non-allowed characters in the strings
    cleaned_columnList = check_and_replace(columnList, NONALLOWEDCHARS, REPLACEMENTCHARS, columnGrab)

    # Get the prefix from the 3rd row (index 2) of the column, if this is not a string (in the case it's an unfilled cell due to merging), we iterate upward to find the least abstracted cell with a string in it. This is intentionally limited, since pulling from negative index values causes a crash
    prefix = df.iloc[2, columnGrab]
    if not(isinstance(prefix, str)): prefix = df.iloc[1, columnGrab] 
    if not(isinstance(prefix, str)): prefix = df.iloc[0, columnGrab]

    # Format each entry and concatenate them with spaces
    formatted_entries = []
    for i, entry in enumerate(cleaned_columnList):
        # Check for and remove any \xxx sections from the text
        sequential_match = re.search(r'(\\[a-z]{3})', entry)
        if sequential_match:
            entry = re.sub(r'\\[a-z]{3}', '', entry)
            if i == 0: formatted_entries.append(f'sequential_name =')
        
        formatted_entries.append(f"{sheet_name.upper()}_{prefix.upper()}_{entry.strip().replace(' ','').replace('-','')}")
    
    concatenatedString = ' '.join(formatted_entries)

    return concatenatedString

def yaml_swap(df, columnGrab, sheet_name, startValue=3):
    # Grabs column data from column =columnGrab from a data frame =df starting at the row=startValue and continuing downward

    # Grab the column data from the dataframe and convert to array
    columnData = df.iloc[startValue:, columnGrab]
    columnList = columnData.to_numpy()
    
    # Check for and replace any non-allowed characters in the strings
    cleaned_columnList = check_and_replace(columnList, NONALLOWEDCHARS, REPLACEMENTCHARS, columnGrab)

    # Get the prefix from the 3rd row (index 2) of the column, if this is not a string (in the case it's an unfilled cell due to merging), we iterate upward to find the least abstracted cell with a string in it. This is intentionally limited, since pulling from negative index values causes a crash
    prefix = df.iloc[2, columnGrab]
    if not(isinstance(prefix, str)): prefix = df.iloc[1, columnGrab] 
    if not(isinstance(prefix, str)): prefix = df.iloc[0, columnGrab]

    yaml_lines = []
    for i, entry in enumerate(cleaned_columnList):
        
        # Check for sequential names, these are names that are in the format \XXX, where XXX is a three-letter code
        entry = str(entry).strip() # Listen idek, it just works, okay? Ensure the entry is treated as a string, allowing numbers in names, and strip whitespace (checkandreplace does this, but its not passing through to here, so we do it again)
        sequential_match = re.search(r'(\\[a-z]{3})', entry)
        if sequential_match:
            code = sequential_match.group(1)
            key = replace_key(sequential_match.group(1)) # Convert key used in spreadsheet to key used by Stellaris
            formatted_entry = f" {sheet_name.upper()}_{prefix.upper()}_{entry.replace(code, f'').strip().replace(' ','').replace('-','')}:0 \"{entry.replace(code, f'${key}$')}\""
        else:
            formatted_entry = f" {sheet_name.upper()}_{prefix.upper()}_{entry.replace(' ','').replace('-','')}:0 \"{entry}\""
        if i == 0 and entry != '':
            formatted_entry = f'\n' + formatted_entry
        yaml_lines.append(formatted_entry)
    
    return '\n'.join(yaml_lines) # AND NOW THE .lstrip() FUCKS IT UP????? WHAT THE FUCK IS PYTHON OMG. defunct:HOW DOES THIS WORK???? .lstrip() removes the leading whitespace, but THERES ONLY ONE WHITESPACE ON EVERY OTHER LINE BARR THE FIRST WTF

def col2num(col):
    # Converts a column letter(s) to a number, since this is plugged into the pandas dataframe, which is zero-indexed, we subtract 1 from the result
    num = 0
    for c in col:
        if c in string.ascii_letters:
            num = num * 26 + (ord(c.upper()) - ord('A')) + 1           
    return num - 1

def num2col(num):
    # Converts a column number to a letter(s), since this is plugged into the pandas dataframe, which is zero-indexed, we add 1 to the result
    col = ''
    while num >= 0:
        col = chr(num % 26 + ord('A')) + col
        num = num // 26 - 1
    return col

def process_sheets(sheets):
    # Loop through each sheet in the sheets dictionary
    for sheet_name, df in sheets.items():
        if sheet_name == "Tutorial":
            documentName = df.iloc[75, col2num('J')] # Grab the document name from the tutorial sheet
            print(f"\nProcessing document: {documentName}")
            continue # Skip the tutorial sheet

        elif df.iloc[(14), col2num('L')] == False: # The 16th row, L column is the "Enable List Processing:" row, if this is set to FALSE, the sheet will be skipped
            print(f"Skipping sheet: {sheet_name}, update the 'Enable List Processing:' cell to TRUE (checked) to process this sheet.")
            continue
        else:
            print(f"Processing sheet: {sheet_name}")

            yamlpath = f'name_list_{sheet_name.upper()}_l_english.yml'
            txtpath =  f'{sheet_name.upper()}.txt'

            # Create a template object from the template.txt file
            with open(r'StellarisNamesListTool\Templates\template.txt', 'r') as file:
                template_string = file.read()
            template = string.Template(template_string)
            
            # Create a dictionary of values to fill into the template
            values = {
                "listname": sheet_name.upper(), # The name of the list is the name of the sheet, this is what is used in the game, so it should be unique
                "categoryname": f'"{df.iloc[7, col2num('L')]}"', # The category name is the type of names list (toxoids, humanoids, etc.), I'm not sure where this is used in the game, but it's here for completeness
                "shipgeneral": concatenate_column_data(df, col2num('AU'), sheet_name),
                "shipcorvette": concatenate_column_data(df, col2num('BC'), sheet_name),
                "shipdestroyer": concatenate_column_data(df, col2num('BD'), sheet_name),
                "shipcruiser": concatenate_column_data(df, col2num('BE'), sheet_name),
                "shipbattleship": concatenate_column_data(df, col2num('BF'), sheet_name),
                "shiptitan": concatenate_column_data(df, col2num('BG'), sheet_name),
                "shipcolossus": concatenate_column_data(df, col2num('BH'), sheet_name),
                "shipjuggernaut": concatenate_column_data(df, col2num('BI'), sheet_name),
                "shipscience": concatenate_column_data(df, col2num('AY'), sheet_name),
                "shipcolonizer": concatenate_column_data(df, col2num('AZ'), sheet_name),
                "shipconstructor": concatenate_column_data(df, col2num('AX'), sheet_name),
                "shiptransport": concatenate_column_data(df, col2num('BL'), sheet_name),
                "shipstarbase": concatenate_column_data(df, col2num('BN'), sheet_name),
                "shipioncannon": concatenate_column_data(df, col2num('BM'), sheet_name),
                "fleetgeneral": concatenate_column_data(df, col2num('BS'), sheet_name),
                "sequentialfleet": concatenate_column_data(df, col2num('BT'), sheet_name),
                "armygeneral": concatenate_column_data(df, col2num('BW'), sheet_name),
                "armydefense": concatenate_column_data(df, col2num('BX'), sheet_name),
                "armyassault": concatenate_column_data(df, col2num('BY'), sheet_name),
                "armyslave": concatenate_column_data(df, col2num('BZ'), sheet_name),
                "armyundead": concatenate_column_data(df, col2num('CA'), sheet_name),
                "armyclone": concatenate_column_data(df, col2num('CB'), sheet_name),
                "armymachinedefence": concatenate_column_data(df, col2num('CC'), sheet_name),
                "armyrobotic": concatenate_column_data(df, col2num('CD'), sheet_name),
                "armyroboticdefense": concatenate_column_data(df, col2num('CE'), sheet_name),
                "armypsionic": concatenate_column_data(df, col2num('CF'), sheet_name),
                "armyxenomorph": concatenate_column_data(df, col2num('CG'), sheet_name),
                "armygenewarrior": concatenate_column_data(df, col2num('CH'), sheet_name),
                "armyoccupation": concatenate_column_data(df, col2num('CI'), sheet_name),
                "armyindividualmachineoccupation": concatenate_column_data(df, col2num('CJ'), sheet_name),
                "armyroboticoccupation": concatenate_column_data(df, col2num('CK'), sheet_name),
                "armyprimitive": concatenate_column_data(df, col2num('CL'), sheet_name),
                "armyindustrial": concatenate_column_data(df, col2num('CM'), sheet_name),
                "armypostatomic": concatenate_column_data(df, col2num('CN'), sheet_name),
                "armymachineassault1": concatenate_column_data(df, col2num('CO'), sheet_name),
                "armymachineassault2": concatenate_column_data(df, col2num('CP'), sheet_name),
                "armymachineassault3": concatenate_column_data(df, col2num('CQ'), sheet_name),
                "armywarpling": concatenate_column_data(df, col2num('CR'), sheet_name),
                "planetgeneral": concatenate_column_data(df, col2num('CV'), sheet_name),
                "planetdesert": concatenate_column_data(df, col2num('CW'), sheet_name),
                "planettropical": concatenate_column_data(df, col2num('DB'), sheet_name),
                "planetarid": concatenate_column_data(df, col2num('CX'), sheet_name),
                "planetcontinental": concatenate_column_data(df, col2num('DA'), sheet_name),
                "planetocean": concatenate_column_data(df, col2num('CZ'), sheet_name),
                "planettundra": concatenate_column_data(df, col2num('DE'), sheet_name),
                "planetarctic": concatenate_column_data(df, col2num('DC'), sheet_name),
                "planetsavannah": concatenate_column_data(df, col2num('CY'), sheet_name),
                "planetalpine": concatenate_column_data(df, col2num('DD'), sheet_name),
                "characterfullgeneral": concatenate_column_data(df, col2num('T'), sheet_name),
                "characterfullfemale": concatenate_column_data(df, col2num('U'), sheet_name),
                "characterfullmale": concatenate_column_data(df, col2num('V'), sheet_name),
                "characterfirstgeneral": concatenate_column_data(df, col2num('X'), sheet_name),
                "characterfirstfemale": concatenate_column_data(df, col2num('Y'), sheet_name),
                "characterfirstmale": concatenate_column_data(df, col2num('Z'), sheet_name),
                "charactersecondgeneral": concatenate_column_data(df, col2num('AB'), sheet_name),
                "charactersecondfemale": concatenate_column_data(df, col2num('AC'), sheet_name),
                "charactersecondmale": concatenate_column_data(df, col2num('AD'), sheet_name),
                "characterregnalfullgeneral": concatenate_column_data(df, col2num('AG'), sheet_name),
                "characterregnalfullfemale": concatenate_column_data(df, col2num('AH'), sheet_name),
                "characterregnalfullmale": concatenate_column_data(df, col2num('AI'), sheet_name),
                "characterregnalfirstgeneral": concatenate_column_data(df, col2num('AK'), sheet_name),
                "characterregnalfirstfemale": concatenate_column_data(df, col2num('AL'), sheet_name),
                "characterregnalfirstmale": concatenate_column_data(df, col2num('AM'), sheet_name),
                "characterregnalsecondgeneral": concatenate_column_data(df, col2num('AO'), sheet_name),
                "characterregnalsecondfemale": concatenate_column_data(df, col2num('AP'), sheet_name),
                "characterregnalsecondmale": concatenate_column_data(df, col2num('AQ'), sheet_name),
            }

            finalNamesList = template.substitute(values) # Fill in the template with the values dictionary
            with open(f'StellarisNamesListTool/{DIRECTORYNAME}/' + txtpath, 'w') as file: # Write the final names list to a file
                file.write(finalNamesList)
            
            # Create a .yml file with the name format "name_list_{sheet_name}_english.yml" from the template.yml file
            with open(r'StellarisNamesListTool\Templates\localizationtemplate.yml', 'r') as file:
                template_string = file.read()
                
            template = string.Template(template_string)
            values = {
                "shipgeneral": yaml_swap(df, col2num('AU'), sheet_name),
                "shipcorvette": yaml_swap(df, col2num('BC'), sheet_name),
                "shipdestroyer": yaml_swap(df, col2num('BD'), sheet_name),
                "shipcruiser": yaml_swap(df, col2num('BE'), sheet_name),
                "shipbattleship": yaml_swap(df, col2num('BF'), sheet_name),
                "shiptitan": yaml_swap(df, col2num('BG'), sheet_name),
                "shipcolossus": yaml_swap(df, col2num('BH'), sheet_name),
                "shipjuggernaut": yaml_swap(df, col2num('BI'), sheet_name),
                "shipscience": yaml_swap(df, col2num('AY'), sheet_name),
                "shipcolonizer": yaml_swap(df, col2num('AZ'), sheet_name),
                "shipconstructor": yaml_swap(df, col2num('AX'), sheet_name),
                "shiptransport": yaml_swap(df, col2num('BL'), sheet_name),
                "shipstarbase": yaml_swap(df, col2num('BN'), sheet_name),
                "shipioncannon": yaml_swap(df, col2num('BM'), sheet_name),
                "fleetgeneral": yaml_swap(df, col2num('BS'), sheet_name),
                "sequentialfleet": yaml_swap(df, col2num('BT'), sheet_name),
                "armygeneral": yaml_swap(df, col2num('BW'), sheet_name),
                "armydefense": yaml_swap(df, col2num('BX'), sheet_name),
                "armyassault": yaml_swap(df, col2num('BY'), sheet_name),
                "armyslave": yaml_swap(df, col2num('BZ'), sheet_name),
                "armyundead": yaml_swap(df, col2num('CA'), sheet_name),
                "armyclone": yaml_swap(df, col2num('CB'), sheet_name),
                "armymachinedefence": yaml_swap(df, col2num('CC'), sheet_name),
                "armyrobotic": yaml_swap(df, col2num('CD'), sheet_name),
                "armyroboticdefense": yaml_swap(df, col2num('CE'), sheet_name),
                "armypsionic": yaml_swap(df, col2num('CF'), sheet_name),
                "armyxenomorph": yaml_swap(df, col2num('CG'), sheet_name),
                "armygenewarrior": yaml_swap(df, col2num('CH'), sheet_name),
                "armyoccupation": yaml_swap(df, col2num('CI'), sheet_name),
                "armyindividualmachineoccupation": yaml_swap(df, col2num('CJ'), sheet_name),
                "armyroboticoccupation": yaml_swap(df, col2num('CK'), sheet_name),
                "armyprimitive": yaml_swap(df, col2num('CL'), sheet_name),
                "armyindustrial": yaml_swap(df, col2num('CM'), sheet_name),
                "armypostatomic": yaml_swap(df, col2num('CN'), sheet_name),
                "armymachineassault1": yaml_swap(df, col2num('CO'), sheet_name),
                "armymachineassault2": yaml_swap(df, col2num('CP'), sheet_name),
                "armymachineassault3": yaml_swap(df, col2num('CQ'), sheet_name),
                "armywarpling": yaml_swap(df, col2num('CR'), sheet_name),
                "planetgeneral": yaml_swap(df, col2num('CV'), sheet_name),
                "planetdesert": yaml_swap(df, col2num('CW'), sheet_name),
                "planettropical": yaml_swap(df, col2num('DB'), sheet_name),
                "planetarid": yaml_swap(df, col2num('CX'), sheet_name),
                "planetcontinental": yaml_swap(df, col2num('DA'), sheet_name),
                "planetocean": yaml_swap(df, col2num('CZ'), sheet_name),
                "planettundra": yaml_swap(df, col2num('DE'), sheet_name),
                "planetarctic": yaml_swap(df, col2num('DC'), sheet_name),
                "planetsavannah": yaml_swap(df, col2num('CY'), sheet_name),
                "planetalpine": yaml_swap(df, col2num('DD'), sheet_name),
                "characterfullgeneral": yaml_swap(df, col2num('T'), sheet_name),
                "characterfullfemale": yaml_swap(df, col2num('U'), sheet_name),
                "characterfullmale": yaml_swap(df, col2num('V'), sheet_name),
                "characterfirstgeneral": yaml_swap(df, col2num('X'), sheet_name),
                "characterfirstfemale": yaml_swap(df, col2num('Y'), sheet_name),
                "characterfirstmale": yaml_swap(df, col2num('Z'), sheet_name),
                "charactersecondgeneral": yaml_swap(df, col2num('AB'), sheet_name),
                "charactersecondfemale": yaml_swap(df, col2num('AC'), sheet_name),
                "charactersecondmale": yaml_swap(df, col2num('AD'), sheet_name),
                "characterregnalfullgeneral": yaml_swap(df, col2num('AG'), sheet_name),
                "characterregnalfullfemale": yaml_swap(df, col2num('AH'), sheet_name),
                "characterregnalfullmale": yaml_swap(df, col2num('AI'), sheet_name),
                "characterregnalfirstgeneral": yaml_swap(df, col2num('AK'), sheet_name),
                "characterregnalfirstfemale": yaml_swap(df, col2num('AL'), sheet_name),
                "characterregnalfirstmale": yaml_swap(df, col2num('AM'), sheet_name),
                "characterregnalsecondgeneral": yaml_swap(df, col2num('AO'), sheet_name),
                "characterregnalsecondfemale": yaml_swap(df, col2num('AP'), sheet_name),
                "characterregnalsecondmale": yaml_swap(df, col2num('AQ'), sheet_name),
            }
            
            # You can add your logic to replace placeholders in the template here
            yml_content = template.substitute(values)

            
            with open(f'StellarisNamesListTool/{DIRECTORYNAME}/' + yamlpath, 'w') as file:
                file.write(yml_content)
            print(f"Sequential entries detected and written to name_list_{sheet_name.upper()}_l_english.yml")

            # Print duplicate information
            for duplicate, indices in sheet_duplicates.items():
                dynamicPadding = max([len(duplicate) for duplicate in sheet_duplicates.keys()]) + 2 #dynamically adjust padding based on longest duplicated word, keeps 'found at:...' aligned
                total_duplicates.append(f"Duplicate entries '{duplicate + "'":<{dynamicPadding}} found at: {', '.join([f'({row}, {col})' for row, col in indices])} in sheet '{sheet_name}'")
            sheet_duplicates.clear()                        #^^^^^^^^^^^^^^^^^^^^^ This absolutely cursed monstrosity makes sure that the output is formatted correctly (left aligned, quoted, assigned width), it's a mess, but it works, so I'm not touching it

            txtfiles.append(txtpath)
            yamlfiles.append(yamlpath)


    return documentName

# Create the directory new names lists will be saved to
try:
    os.mkdir('StellarisNamesListTool/' + DIRECTORYNAME)
    print(f"\nDirectory '{DIRECTORYNAME}' created successfully.")
except FileExistsError:
    print(f"\nDirectory '{DIRECTORYNAME}' already exists, continuing.")

# Get URLs from user input and split them into a list for processing
inputString = input("Enter the URL of the Google Sheet, multiple documents can be given seperated by commas, multiple sheets in the same document will be processed: ")
urls = inputString.split(',')

# Loop through the URLs provided by user
for i, url in enumerate(urls):
    # Convert the Google Sheet URL to a CSV export URL
    new_url = convert_google_sheet_url(url.strip())
    sheets = pd.read_excel(new_url, sheet_name=None)
    documentName = process_sheets(sheets)

    # Print duplicate information
    for duplicate_info in total_duplicates:
        print(duplicate_info)
    if len(total_duplicates) > 0:
        print("Duplicates removed from final .txt file, although we suggest removing them from the main document anyway.")
        total_duplicates.clear()
    
    if len(urls) > 1:
        if i < len(urls) - 1:
            print(f'{documentName} has been processed successfully. Beginning next document...')
        else:
            print(f'{documentName} has been processed successfully.\nAll documents processed, your files are in the ASNLT_output folder.\n\n')
    else:    
        print(f'{documentName} has been processed successfully. \nYour files are in the ASNLT_output folder.\n\n')

inputString = input("Would you like to move the files to the Stellaris/mod folder? Y/N: ")
if inputString == 'Y': 
    modfilelocation = r"C:\Users\Avi\Documents\Paradox Interactive\Stellaris\mod\TarpitNameslists"
    for file in yamlfiles:  
        os.rename(f'StellarisNamesListTool/{DIRECTORYNAME}/' + file, modfilelocation + '\localisation\english' + file)
                  
    for file in txtfiles:  
        os.rename(f'StellarisNamesListTool/{DIRECTORYNAME}/' + file, modfilelocation + '\localisation\english' + file)